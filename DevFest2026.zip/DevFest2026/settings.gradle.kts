pluginManagement {
    repositories {
        val artifactStoreHost = providers.environmentVariable("ARTIFACT_STORE_HOST").get()
        maven("https://$artifactStoreHost/artifactory/android/") {
            credentials {
                username = providers.environmentVariable("ARTIFACT_STORE_USER").get()
                password = providers.environmentVariable("ARTIFACT_STORE_SECRET").get()
            }
        }
    }
}

dependencyResolutionManagement {
    repositories {
        val artifactStoreHost = providers.environmentVariable("ARTIFACT_STORE_HOST").get()
        maven("https://$artifactStoreHost/artifactory/android/") {
            credentials {
                username = providers.environmentVariable("ARTIFACT_STORE_USER").get()
                password = providers.environmentVariable("ARTIFACT_STORE_SECRET").get()
            }
        }
    }
}


plugins {
    id("org.gradle.toolchains.foojay-resolver-convention") version "1.0.0"
}
rootProject.name = "WordOfMouth"
include(":androidApp")