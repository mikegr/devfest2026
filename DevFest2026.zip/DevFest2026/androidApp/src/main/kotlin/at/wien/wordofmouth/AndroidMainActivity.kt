package at.wien.wordofmouth

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalUriHandler
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.ViewModelProvider

private val AndroidCream = Color(0xFFF8F5EE)
private val AndroidGreen = Color(0xFF3F5944)
private val AndroidClay = Color(0xFFB65035)
private val AndroidMuted = Color(0xFF77796C)

class AndroidMainActivity : ComponentActivity() {
    private val food by lazy { ViewModelProvider(this)[AndroidFoodViewModel::class.java] }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            MaterialTheme(
                colorScheme = lightColorScheme(
                    primary = AndroidGreen, secondary = AndroidClay,
                    background = AndroidCream, surface = Color.White,
                    onBackground = Color(0xFF292E27), onSurface = Color(0xFF292E27),
                ),
            ) {
                AndroidFoodApp(food)
            }
        }
    }

    override fun onStop() {
        food.stopSpeech()
        super.onStop()
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun AndroidFoodApp(food: AndroidFoodViewModel) {
    val state = food.state
    val selected = state.selectedDish
    BackHandler(enabled = selected != null && !state.showSettings) { food.closeDish() }
    Scaffold(
        modifier = Modifier.fillMaxSize().imePadding(),
        containerColor = AndroidCream,
        topBar = {
            TopAppBar(
                title = { Text("Word of Mouth", fontFamily = FontFamily.Serif, fontSize = 24.sp) },
                navigationIcon = {
                    if (selected != null) TextButton(onClick = food::closeDish) { Text("Back") }
                },
                actions = {
                    if (state.speakingDishName != null) TextButton(onClick = food::stopSpeech) { Text("Stop audio") }
                    TextButton(onClick = { food.settings(true) }) { Text("Settings") }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = AndroidCream),
            )
        },
        bottomBar = {
            if (selected != null) AndroidChatComposer(food)
        },
    ) { padding ->
        if (selected == null) {
            AndroidCatalog(food, Modifier.padding(padding))
        } else {
            AndroidDishDetail(food, selected, Modifier.padding(padding))
        }
    }
    if (state.showSettings) AndroidSettings(food)
}

@Composable
private fun AndroidCatalog(food: AndroidFoodViewModel, modifier: Modifier) {
    val state = food.state
    val visible = remember(state.category, state.vegetarianOnly, state.search) {
        filterDishes(dishes, state.category, state.vegetarianOnly, state.search)
    }
    LazyColumn(
        modifier = modifier.fillMaxSize(),
        contentPadding = PaddingValues(20.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp),
    ) {
        item {
            Text("SERVUS, FOOD LOVER", color = AndroidClay, fontSize = 11.sp, letterSpacing = 2.sp)
            Spacer(Modifier.height(8.dp))
            Text("A taste of Vienna.\nA word at a time.", fontFamily = FontFamily.Serif, fontSize = 34.sp, lineHeight = 39.sp)
            Spacer(Modifier.height(8.dp))
            Text("Discover the classics. Learn to say them.\nOrder like you belong here.", color = AndroidMuted, lineHeight = 23.sp)
            Spacer(Modifier.height(10.dp))
            Text("${state.learned.size} / ${dishes.size} practised", color = AndroidGreen, fontSize = 12.sp)
        }
        item {
            OutlinedTextField(
                state.search, food::search, modifier = Modifier.fillMaxWidth(), singleLine = true,
                label = { Text("Search dishes") }, placeholder = { Text("Name or ingredient") },
                shape = RoundedCornerShape(16.dp),
                trailingIcon = {
                    if (state.search.isNotEmpty()) TextButton(onClick = { food.search("") }) { Text("Clear") }
                },
            )
            Spacer(Modifier.height(8.dp))
            FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                FilterChip(state.category == null, { food.category(null) }, label = { Text("All dishes") })
                DishCategory.entries.forEach { category ->
                    FilterChip(state.category == category, { food.category(category) }, label = { Text(category.label) })
                }
            }
            FilterChip(state.vegetarianOnly, food::toggleVegetarian, label = { Text("Vegetarian only") })
            Text("Vegetarian may include eggs and dairy.", color = AndroidMuted, fontSize = 11.sp)
            Spacer(Modifier.height(8.dp))
            Text("${visible.size} of ${dishes.size} dishes", color = AndroidMuted, fontSize = 12.sp)
        }
        if (visible.isEmpty()) {
            item {
                Surface(shape = RoundedCornerShape(20.dp), color = Color.White) {
                    Column(Modifier.fillMaxWidth().padding(20.dp)) {
                        Text("Nothing on this menu yet", fontFamily = FontFamily.Serif, fontSize = 25.sp)
                        Spacer(Modifier.height(8.dp))
                        Text(
                            if (state.category != null && dishes.none { it.category == state.category })
                                "This collection doesn't contain ${state.category.label.lowercase()} yet."
                            else "No dishes match your search and filters. Try another name, ingredient or category.",
                            color = AndroidMuted,
                        )
                        TextButton(onClick = food::clearFilters) { Text("Clear all filters") }
                    }
                }
            }
        }
        visible.groupBy { it.category }.forEach { (category, group) ->
            item(key = category) { Text(category.label, fontFamily = FontFamily.Serif, fontSize = 27.sp) }
            group.forEach { dish ->
                item(key = dish.name) { AndroidDishCard(food, dish, true) }
            }
        }
        item {
            Text("A LITTLE LOCAL KNOW-HOW", color = AndroidClay, fontSize = 11.sp, letterSpacing = 1.sp)
            Spacer(Modifier.height(8.dp))
            Text("“Paradeiser” means “Tomate” (tomato). Austrian words are used in Vienna too, but aren't all uniquely Viennese.",
                color = AndroidMuted, fontSize = 13.sp, lineHeight = 20.sp)
        }
    }
}

@Composable
private fun AndroidDishImage(dish: Dish) {
    val context = LocalContext.current
    val image = remember(dish.photo.resource) {
        context.assets.open(dish.photo.resource).use { stream ->
            requireNotNull(android.graphics.BitmapFactory.decodeStream(
                stream, null, android.graphics.BitmapFactory.Options().apply { inSampleSize = 2 },
            )) { "Bundled photo cannot be decoded: ${dish.photo.resource}" }.asImageBitmap()
        }
    }
    Image(
        bitmap = image, contentDescription = "A serving of ${dish.name}", contentScale = ContentScale.Crop,
        modifier = Modifier.fillMaxWidth().height(190.dp).clip(RoundedCornerShape(14.dp)),
    )
}

@Composable
private fun AndroidDishCard(food: AndroidFoodViewModel, dish: Dish, openOnClick: Boolean) {
    val state = food.state
    val uri = LocalUriHandler.current
    val cardModifier = Modifier.fillMaxWidth().then(
        if (openOnClick) Modifier.clickable { food.openDish(dish) } else Modifier,
    )
    Surface(modifier = cardModifier, color = Color.White, shape = RoundedCornerShape(22.dp)) {
        Column(Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            AndroidDishImage(dish)
            Text("Photo: ${dish.photo.author}", fontSize = 10.sp, color = AndroidMuted,
                modifier = Modifier.clickable { uri.openUri(dish.photo.source) })
            Text("${dish.photo.license} · displayed cropped", fontSize = 10.sp, color = AndroidMuted,
                modifier = Modifier.clickable { uri.openUri(dish.photo.licenseUrl) })
            Text(dish.category.label.uppercase(), fontSize = 10.sp, color = AndroidClay, letterSpacing = 1.sp)
            if (dish.isVegetarian) Text("Vegetarian", color = AndroidGreen, fontSize = 12.sp)
            Text(dish.name, fontFamily = FontFamily.Serif, fontSize = 30.sp)
            Text(dish.pronunciation, color = AndroidClay, fontWeight = FontWeight.Bold, fontSize = 17.sp)
            Text("Approximate phonetic spelling", color = AndroidMuted, fontSize = 11.sp)
            FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Button(onClick = { food.pronounce(dish) }, enabled = state.speakingDishName == null) {
                    Text(if (state.speakingDishName == dish.name) "Speaking…" else "Listen with Gemini")
                }
                OutlinedButton(onClick = { food.pronounce(dish, true) }, enabled = state.speakingDishName == null) {
                    Text("Slowly")
                }
            }
            if (state.speechErrorDishName == dish.name) {
                state.speechError?.let { Text(it, color = MaterialTheme.colorScheme.error, fontSize = 13.sp) }
            }
            Text("Gemini AI voice, prompted with a Viennese accent. Pronunciation may vary.",
                color = AndroidMuted, fontSize = 11.sp, lineHeight = 16.sp)
            Text(dish.tip, color = AndroidMuted, fontSize = 13.sp, lineHeight = 20.sp)
            AndroidFact("LOCAL NAME", dish.dialectName ?: "The same dish name is used in Vienna.")
            AndroidFact("AUSTRIAN WORDS", dish.localVocabulary)
            Text(dish.description, fontSize = 14.sp, lineHeight = 21.sp)
            AndroidFact("MADE WITH", dish.ingredients)
            AndroidFact("FROM", dish.origin)
            AndroidFact("WHEN TO ENJOY", dish.occasion)
            AndroidFact("AT THE TABLE", dish.order)
            if (openOnClick) {
                TextButton(onClick = { food.openDish(dish) }) { Text("Learn with Leni →") }
            } else {
                TextButton(onClick = { food.toggleLearned(dish) }) {
                    Text(if (dish.name in state.learned) "Practised ✓ · Undo" else "I've practised this dish")
                }
            }
        }
    }
}

@Composable
private fun AndroidFact(label: String, text: String) {
    Column {
        Text(label, color = AndroidClay, fontSize = 10.sp, letterSpacing = 1.sp)
        Spacer(Modifier.height(3.dp))
        Text(text, color = AndroidMuted, fontSize = 13.sp, lineHeight = 20.sp)
    }
}

@Composable
private fun AndroidDishDetail(food: AndroidFoodViewModel, dish: Dish, modifier: Modifier) {
    val state = food.state
    val messages = state.conversations[dish.name].orEmpty()
    val scroll = rememberScrollState()
    LaunchedEffect(messages.size, state.pendingQuestion) {
        if (messages.isNotEmpty() || state.pendingQuestion != null) scroll.animateScrollTo(scroll.maxValue)
    }
    Column(
        modifier.fillMaxSize().verticalScroll(scroll).padding(20.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp),
    ) {
        AndroidDishCard(food, dish, false)
        Text("Meet Leni", fontFamily = FontFamily.Serif, fontSize = 30.sp)
        Text("Your Viennese AI local · Text coach", color = AndroidMuted, fontSize = 12.sp)
        AndroidChatBubble("Servus! Let's learn to say ${dish.name} and order it with confidence. I can explain the sounds, but I can't hear your voice.", false)
        if (messages.isEmpty()) {
            FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                SuggestionChip(onClick = { food.send("Teach me to pronounce ${dish.name}, step by step.") },
                    enabled = state.pendingQuestion == null, label = { Text("Break it down") })
                SuggestionChip(onClick = { food.send("How do I order ${dish.name} in a Viennese restaurant?") },
                    enabled = state.pendingQuestion == null, label = { Text("Help me order") })
            }
        }
        messages.forEach { AndroidChatBubble(it.text, it.fromUser) }
        state.pendingQuestion?.let {
            AndroidChatBubble(it, true)
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                CircularProgressIndicator(Modifier.size(18.dp), strokeWidth = 2.dp)
                Text("Leni is thinking…", color = AndroidMuted, fontSize = 13.sp)
            }
        }
        state.chatError?.let { Text(it, color = MaterialTheme.colorScheme.error) }
    }
}

@Composable
private fun AndroidChatBubble(text: String, user: Boolean) {
    Surface(color = if (user) AndroidGreen else Color.White, shape = RoundedCornerShape(18.dp)) {
        Text(text, modifier = Modifier.fillMaxWidth().padding(16.dp),
            color = if (user) Color.White else MaterialTheme.colorScheme.onSurface, fontSize = 14.sp, lineHeight = 23.sp)
    }
}

@Composable
private fun AndroidChatComposer(food: AndroidFoodViewModel) {
    val state = food.state
    Surface(color = AndroidCream, tonalElevation = 2.dp) {
        Column(Modifier.fillMaxWidth().navigationBarsPadding().padding(horizontal = 16.dp, vertical = 8.dp)) {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(
                    state.chatInput, food::chatInput, modifier = Modifier.weight(1f),
                    enabled = state.pendingQuestion == null, maxLines = 3,
                    placeholder = { Text("Ask Leni…") }, shape = RoundedCornerShape(16.dp),
                    keyboardOptions = KeyboardOptions(imeAction = ImeAction.Send),
                    keyboardActions = KeyboardActions(onSend = { food.send() }),
                )
                Button(onClick = { food.send() }, enabled = state.pendingQuestion == null && state.chatInput.isNotBlank(),
                    modifier = Modifier.padding(top = 7.dp)) { Text("Send") }
            }
            Spacer(Modifier.height(6.dp))
            Text("Messages and speech prompts are sent to Google. Model: ${state.model}", color = AndroidMuted, fontSize = 10.sp)
        }
    }
}

@Composable
private fun AndroidSettings(food: AndroidFoodViewModel) {
    var key by remember { mutableStateOf(food.apiKey) }
    var model by remember { mutableStateOf(food.state.model) }
    var speechModel by remember { mutableStateOf(food.state.speechModel) }
    var attempted by remember { mutableStateOf(false) }
    val keyError = apiKeyValidationError(key)
    val modelError = modelValidationError(model.trim())
    val speechError = modelValidationError(speechModel.trim())
    AlertDialog(
        onDismissRequest = { food.settings(false) },
        title = { Text("Meet your AI local", fontFamily = FontFamily.Serif) },
        text = {
            Column(Modifier.heightIn(max = 420.dp).verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(12.dp)) {
                Text("Use a Gemini API key from Google AI Studio. Your key stays in memory and is never saved to disk.")
                OutlinedTextField(key, { key = it }, label = { Text("Gemini API key") }, singleLine = true,
                    visualTransformation = PasswordVisualTransformation(),
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password),
                    isError = attempted && keyError != null,
                    supportingText = { if (attempted) keyError?.let { Text(it) } })
                OutlinedTextField(model, { model = it }, label = { Text("Text model ID") }, singleLine = true,
                    isError = attempted && modelError != null,
                    supportingText = { if (attempted) modelError?.let { Text(it) } })
                OutlinedTextField(speechModel, { speechModel = it }, label = { Text("Speech model ID") }, singleLine = true,
                    isError = attempted && speechError != null,
                    supportingText = { if (attempted) speechError?.let { Text(it) } })
                Text("Text: gemini-3.5-flash. Speech: $DEFAULT_SPEECH_MODEL, Aoede voice. Availability depends on your account; errors never silently switch models.",
                    color = AndroidMuted, fontSize = 12.sp)
                Text("Questions, conversation history and speech prompts are sent to Google. Gemini audio plays locally. No microphone is used.",
                    color = AndroidMuted, fontSize = 12.sp)
            }
        },
        confirmButton = {
            TextButton(onClick = {
                attempted = true
                if (keyError == null && modelError == null && speechError == null) food.saveSettings(key, model, speechModel)
            }) { Text("Save for this session") }
        },
        dismissButton = { TextButton(onClick = { food.settings(false) }) { Text("Cancel") } },
    )
}
