package at.wien.wordofmouth

import android.app.Application
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.Job
import kotlinx.coroutines.launch

data class AndroidFoodState(
    val selectedDish: Dish? = null,
    val category: DishCategory? = null,
    val vegetarianOnly: Boolean = false,
    val search: String = "",
    val learned: Set<String> = emptySet(),
    val showSettings: Boolean = false,
    val model: String = "gemini-3.5-flash",
    val speechModel: String = DEFAULT_SPEECH_MODEL,
    val conversations: Map<String, List<ChatMessage>> = emptyMap(),
    val chatInput: String = "",
    val pendingQuestion: String? = null,
    val chatError: String? = null,
    val speakingDishName: String? = null,
    val speechError: String? = null,
    val speechErrorDishName: String? = null,
)

class AndroidFoodViewModel(application: Application) : AndroidViewModel(application) {
    var state by mutableStateOf(AndroidFoodState())
        private set
    var apiKey by mutableStateOf("")
        private set
    private val coach = GeminiCoach()
    private val speech = GeminiSpeech()
    private val player = AndroidAudioPlayer(application)
    private var speechJob: Job? = null
    private var chatJob: Job? = null
    private var chatRequestId = 0

    fun search(value: String) { state = state.copy(search = value) }
    fun category(value: DishCategory?) { state = state.copy(category = value) }
    fun toggleVegetarian() { state = state.copy(vegetarianOnly = !state.vegetarianOnly) }
    fun clearFilters() { state = state.copy(category = null, vegetarianOnly = false, search = "") }
    fun settings(visible: Boolean) { state = state.copy(showSettings = visible) }
    fun chatInput(value: String) { state = state.copy(chatInput = value) }

    fun openDish(dish: Dish) {
        state = state.copy(selectedDish = dish, chatInput = "", chatError = null)
    }

    fun closeDish() {
        chatRequestId++
        chatJob?.cancel()
        stopSpeech()
        state = state.copy(selectedDish = null, chatInput = "", chatError = null, pendingQuestion = null)
    }

    fun saveSettings(key: String, model: String, speechModel: String) {
        apiKey = key.trim()
        state = state.copy(model = model.trim(), speechModel = speechModel.trim(), showSettings = false, chatError = null)
    }

    fun toggleLearned(dish: Dish) {
        val learned = if (dish.name in state.learned) state.learned - dish.name else state.learned + dish.name
        state = state.copy(learned = learned)
    }

    fun send(question: String = state.chatInput) {
        val dish = state.selectedDish ?: return
        if (state.pendingQuestion != null || question.isBlank()) return
        if (apiKey.isBlank()) {
            state = state.copy(showSettings = true, chatError = "Add your Gemini API key, then send your question again.")
            return
        }
        val text = question.trim()
        val requestId = ++chatRequestId
        val history = state.conversations[dish.name].orEmpty() + ChatMessage(text, true)
        val key = apiKey
        val model = state.model
        state = state.copy(pendingQuestion = text, chatInput = "", chatError = null)
        chatJob = viewModelScope.launch {
            try {
                val answer = coach.reply(key, model, dish, history)
                if (requestId == chatRequestId) {
                    state = state.copy(conversations = state.conversations + (dish.name to (history + ChatMessage(answer, false))))
                }
            } catch (error: CoachException) {
                if (requestId == chatRequestId) state = state.copy(chatError = error.message, chatInput = text)
            } finally {
                if (requestId == chatRequestId) state = state.copy(pendingQuestion = null)
            }
        }
    }

    fun pronounce(dish: Dish, slow: Boolean = false) {
        if (state.speakingDishName != null) return
        if (apiKey.isBlank()) {
            state = state.copy(
                showSettings = true, speechErrorDishName = dish.name,
                speechError = "Add your Gemini API key, then press Listen again.",
            )
            return
        }
        val key = apiKey
        val model = state.speechModel
        state = state.copy(speakingDishName = dish.name, speechError = null, speechErrorDishName = dish.name)
        speechJob = viewModelScope.launch {
            try {
                player.play(speech.generate(key, model, dish, slow))
            } catch (error: CoachException) {
                state = state.copy(speechError = error.message)
            } finally {
                state = state.copy(speakingDishName = null)
            }
        }
    }

    fun stopSpeech() {
        speechJob?.cancel()
        player.stop()
    }

    override fun onCleared() {
        stopSpeech()
        super.onCleared()
    }
}
