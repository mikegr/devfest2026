package at.wien.wordofmouth

import android.content.Context
import android.media.AudioAttributes
import android.media.AudioFocusRequest
import android.media.AudioFormat
import android.media.AudioManager
import android.media.AudioTrack
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.TimeoutCancellationException
import kotlinx.coroutines.currentCoroutineContext
import kotlinx.coroutines.delay
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.withContext
import kotlinx.coroutines.withTimeout

class AndroidAudioPlayer(context: Context) {
    private val manager = context.getSystemService(AudioManager::class.java)
    private val lock = Any()
    private var activeTrack: AudioTrack? = null

    suspend fun play(audio: SpeechAudio) = withContext(Dispatchers.IO) {
        val coroutine = currentCoroutineContext()
        coroutine.ensureActive()
        val attributes = AudioAttributes.Builder()
            .setUsage(AudioAttributes.USAGE_MEDIA)
            .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
            .build()
        var focusLost = false
        val focus = AudioFocusRequest.Builder(AudioManager.AUDIOFOCUS_GAIN_TRANSIENT_MAY_DUCK)
            .setAudioAttributes(attributes)
            .setOnAudioFocusChangeListener { change ->
                if (change <= AudioManager.AUDIOFOCUS_LOSS) {
                    synchronized(lock) {
                        focusLost = true
                        activeTrack?.takeIf { it.playState == AudioTrack.PLAYSTATE_PLAYING }?.pause()
                    }
                }
            }.build()
        if (manager.requestAudioFocus(focus) != AudioManager.AUDIOFOCUS_REQUEST_GRANTED) {
            throw CoachException("Another app is using audio. Try the pronunciation again.")
        }
        var track: AudioTrack? = null
        try {
            val output = AudioTrack.Builder()
                .setAudioAttributes(attributes)
                .setAudioFormat(AudioFormat.Builder().setSampleRate(audio.sampleRate)
                    .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                    .setChannelMask(AudioFormat.CHANNEL_OUT_MONO).build())
                .setTransferMode(AudioTrack.MODE_STATIC)
                .setBufferSizeInBytes(audio.bytes.size)
                .build()
            track = output
            // Static tracks become initialized only after receiving their PCM data.
            if (output.state == AudioTrack.STATE_UNINITIALIZED) throw CoachException("Couldn't initialize speech playback.")
            synchronized(lock) { activeTrack = output }
            var offset = 0
            while (offset < audio.bytes.size) {
                coroutine.ensureActive()
                val written = output.write(audio.bytes, offset, audio.bytes.size - offset, AudioTrack.WRITE_BLOCKING)
                if (written <= 0) throw CoachException("Your audio device couldn't play this pronunciation.")
                offset += written
            }
            synchronized(lock) {
                coroutine.ensureActive()
                if (output.state != AudioTrack.STATE_INITIALIZED) throw CoachException("Couldn't load the pronunciation audio.")
                if (focusLost) throw CoachException("Speech was interrupted by another app.")
                output.play()
            }
            val frames = audio.bytes.size / 2
            val duration = frames.toLong() * 1000 / audio.sampleRate
            try {
                withTimeout(duration + 5000) {
                    while ((output.playbackHeadPosition.toLong() and 0xffffffffL) < frames) {
                        if (synchronized(lock) { focusLost }) throw CoachException("Speech was interrupted by another app.")
                        delay(20)
                    }
                }
            } catch (_: TimeoutCancellationException) {
                throw CoachException("Audio playback didn't finish. Check your sound settings and try again.")
            }
        } catch (_: IllegalArgumentException) {
            throw CoachException("Your device doesn't support this speech format.")
        } catch (_: IllegalStateException) {
            coroutine.ensureActive()
            throw CoachException("Audio playback was interrupted. Please try again.")
        } finally {
            synchronized(lock) {
                activeTrack = null
                track?.release()
            }
            manager.abandonAudioFocusRequest(focus)
        }
    }

    fun stop() {
        synchronized(lock) {
            activeTrack?.takeIf { it.playState == AudioTrack.PLAYSTATE_PLAYING }?.pause()
        }
    }
}
