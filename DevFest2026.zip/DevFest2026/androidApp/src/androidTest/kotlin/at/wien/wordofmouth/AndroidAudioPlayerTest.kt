package at.wien.wordofmouth

import android.content.Context
import androidx.test.core.app.ActivityScenario
import androidx.test.core.app.ApplicationProvider
import androidx.test.ext.junit.runners.AndroidJUnit4
import java.nio.ByteBuffer
import java.nio.ByteOrder
import kotlinx.coroutines.runBlocking
import kotlinx.coroutines.withTimeout
import org.junit.Test
import org.junit.runner.RunWith
import kotlin.math.PI
import kotlin.math.sin

@RunWith(AndroidJUnit4::class)
class AndroidAudioPlayerTest {
    @Test
    fun playsMonoPcmAndCanPlayAnotherPronunciation() {
        val rate = 24000
        val frames = rate / 5
        val samples = ByteBuffer.allocate(frames * 2).order(ByteOrder.LITTLE_ENDIAN)
        repeat(frames) { frame ->
            samples.putShort((sin(2 * PI * 440 * frame / rate) * 1800).toInt().toShort())
        }
        val audio = SpeechAudio(samples.array(), rate)
        ActivityScenario.launch(AndroidMainActivity::class.java).use {
            val player = AndroidAudioPlayer(ApplicationProvider.getApplicationContext<Context>())
            try {
                runBlocking {
                    withTimeout(8000) {
                        player.play(audio)
                        player.play(audio)
                    }
                }
            } finally {
                player.stop()
            }
        }
    }
}
