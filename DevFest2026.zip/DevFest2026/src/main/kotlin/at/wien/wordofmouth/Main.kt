package at.wien.wordofmouth

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalUriHandler
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Window
import androidx.compose.ui.window.application
import androidx.compose.ui.window.rememberWindowState
import kotlinx.coroutines.launch
import kotlinx.coroutines.Job

private val Cream = Color(0xFFF8F5EE)
private val Ink = Color(0xFF292E27)
private val Green = Color(0xFF3F5944)
private val Clay = Color(0xFFB65035)
private val Muted = Color(0xFF77796C)
private val Line = Color(0xFFE4E1D7)

fun main() = application {
    Window(
        onCloseRequest = ::exitApplication,
        title = "Word of Mouth · A taste of Vienna",
        state = rememberWindowState(width = 1240.dp, height = 900.dp),
    ) {
        LaunchedEffect(Unit) { window.minimumSize = java.awt.Dimension(1050, 720) }
        MaterialTheme(
            colorScheme = lightColorScheme(
                primary = Green, secondary = Clay, background = Cream,
                surface = Color.White, onSurface = Ink, onBackground = Ink,
            ),
        ) {
            VienneseApp()
        }
    }
}

@Composable
private fun VienneseApp() {
    var selected by remember { mutableStateOf(dishes.first()) }
    var category by remember { mutableStateOf<DishCategory?>(null) }
    var vegetarianOnly by remember { mutableStateOf(false) }
    var search by remember { mutableStateOf("") }
    val visibleDishes = remember(category, vegetarianOnly, search) {
        filterDishes(dishes, category, vegetarianOnly, search)
    }
    var learned by remember { mutableStateOf(setOf<String>()) }
    var showSettings by remember { mutableStateOf(false) }
    var apiKey by remember { mutableStateOf(System.getenv("GEMINI_API_KEY").orEmpty()) }
    var model by remember { mutableStateOf(System.getenv("GEMINI_MODEL")?.takeIf { it.isNotBlank() } ?: "gemini-3.5-flash") }
    var speechModel by remember {
        mutableStateOf(System.getenv("GEMINI_TTS_MODEL")?.takeIf { it.isNotBlank() } ?: DEFAULT_SPEECH_MODEL)
    }
    var messages by remember(selected) { mutableStateOf(listOf<ChatMessage>()) }
    var input by remember(selected) { mutableStateOf("") }
    var pending by remember { mutableStateOf<String?>(null) }
    var error by remember { mutableStateOf<String?>(null) }
    var audioBusy by remember { mutableStateOf(false) }
    var audioDishName by remember { mutableStateOf<String?>(null) }
    var audioError by remember { mutableStateOf<String?>(null) }
    var audioErrorDishName by remember { mutableStateOf<String?>(null) }
    var audioJob by remember { mutableStateOf<Job?>(null) }
    val coach = remember { GeminiCoach() }
    val speech = remember { GeminiSpeech() }
    val audio = remember { PronunciationAudio() }
    val scope = rememberCoroutineScope()
    val chatScroll = rememberScrollState()
    DisposableEffect(Unit) { onDispose { audio.stop() } }
    LaunchedEffect(messages.size, pending, error) { chatScroll.animateScrollTo(chatScroll.maxValue) }

    fun pronounce(dish: Dish, slow: Boolean = false) {
        if (audioBusy) return
        audioError = null
        audioErrorDishName = dish.name
        if (apiKey.isBlank()) {
            audioError = "Add your Gemini API key in Settings, then press Listen again."
            showSettings = true
            return
        }
        audioBusy = true
        audioDishName = dish.name
        audioJob = scope.launch {
            try {
                val generated = speech.generate(apiKey, speechModel, dish, slow)
                audio.play(generated)
            } catch (failure: CoachException) {
                audioError = failure.message
            } finally {
                audioBusy = false
                audioDishName = null
            }
        }
    }

    fun send(text: String) {
        if (pending != null || text.isBlank()) return
        if (apiKey.isBlank()) {
            showSettings = true
            error = "Add an API key to start your conversation. Your question hasn't been sent."
            return
        }
        val question = text.trim()
        val history = messages + ChatMessage(question, true)
        pending = question
        error = null
        input = ""
        scope.launch {
            try {
                val reply = coach.reply(apiKey, model, selected, history)
                messages = history + ChatMessage(reply, false)
            } catch (failure: CoachException) {
                error = failure.message
                input = question
            } finally {
                pending = null
            }
        }
    }

    Row(Modifier.fillMaxSize().background(Cream)) {
        Column(
            Modifier.width(90.dp).fillMaxHeight().background(Green).padding(vertical = 32.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
        ) {
            Text("w.", fontFamily = FontFamily.Serif, fontSize = 36.sp, color = Cream)
            Spacer(Modifier.height(48.dp))
            Text("MENU", color = Color(0xFFCDD7C9), fontSize = 10.sp, letterSpacing = 2.sp)
            Spacer(Modifier.height(12.dp))
            Surface(color = Cream.copy(alpha = 0.13f), shape = RoundedCornerShape(16.dp)) {
                Text("Wien", color = Cream, modifier = Modifier.padding(14.dp), fontSize = 13.sp)
            }
            Spacer(Modifier.weight(1f))
            TextButton(onClick = { showSettings = true }) {
                Text("Settings", color = Cream, fontSize = 11.sp)
            }
        }
        Column(Modifier.weight(1f).fillMaxHeight().padding(horizontal = 32.dp, vertical = 28.dp)) {
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text("WORD OF MOUTH", fontSize = 13.sp, letterSpacing = 3.sp, fontWeight = FontWeight.Bold)
                    Text("Good food. Better pronunciation.", color = Muted, fontSize = 12.sp)
                }
                Surface(color = Color(0xFFE8EDDF), shape = CircleShape) {
                    Text("${learned.size} / 4 practised", color = Green, fontSize = 12.sp, modifier = Modifier.padding(12.dp))
                }
            }
            Spacer(Modifier.height(30.dp))
            Row(Modifier.fillMaxSize(), horizontalArrangement = Arrangement.spacedBy(28.dp)) {
                Column(Modifier.weight(1f).verticalScroll(rememberScrollState())) {
                    Text("SERVUS, FOOD LOVER", color = Clay, fontSize = 11.sp, letterSpacing = 2.sp, fontWeight = FontWeight.Bold)
                    Spacer(Modifier.height(8.dp))
                    Text("A taste of Vienna.\nA word at a time.", fontFamily = FontFamily.Serif, fontSize = 38.sp, lineHeight = 43.sp)
                    Spacer(Modifier.height(12.dp))
                    Text("Discover the classics. Learn to say them.\nOrder like you belong here.", color = Muted, fontSize = 14.sp, lineHeight = 22.sp)
                    Spacer(Modifier.height(20.dp))
                    OutlinedTextField(
                        value = search, onValueChange = { search = it }, singleLine = true,
                        label = { Text("Search dishes") },
                        placeholder = { Text("Name or ingredient", fontSize = 12.sp) },
                        modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(16.dp),
                        trailingIcon = {
                            if (search.isNotEmpty()) TextButton(onClick = { search = "" }) { Text("Clear") }
                        },
                    )
                    Spacer(Modifier.height(10.dp))
                    FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        FilterChip(
                            selected = category == null, onClick = { category = null },
                            label = { Text("All dishes", fontSize = 12.sp) },
                        )
                        DishCategory.entries.forEach { filter ->
                            FilterChip(
                                selected = category == filter, onClick = { category = filter },
                                label = { Text(filter.label, fontSize = 12.sp) },
                            )
                        }
                    }
                    FilterChip(
                        selected = vegetarianOnly, onClick = { vegetarianOnly = !vegetarianOnly },
                        label = { Text("Vegetarian only", fontSize = 12.sp) },
                    )
                    Text("Vegetarian may include eggs and dairy.", color = Muted, fontSize = 11.sp)
                    Spacer(Modifier.height(12.dp))
                    Text("${visibleDishes.size} of ${dishes.size} dishes", color = Muted, fontSize = 12.sp)
                    Spacer(Modifier.height(12.dp))
                    if (visibleDishes.isEmpty()) {
                        Surface(color = Color.White, shape = RoundedCornerShape(18.dp)) {
                            Column(Modifier.fillMaxWidth().padding(20.dp)) {
                                Text("Nothing on this menu yet", fontFamily = FontFamily.Serif, fontSize = 23.sp)
                                Spacer(Modifier.height(8.dp))
                                Text(
                                    if (category != null && dishes.none { it.category == category })
                                        "This collection doesn't contain ${category?.label?.lowercase()} yet."
                                    else "No dishes match your search and filters. Try another name, ingredient or category.",
                                    color = Muted, fontSize = 13.sp, lineHeight = 20.sp,
                                )
                                TextButton(onClick = { category = null; vegetarianOnly = false; search = "" }) {
                                    Text("Clear all filters")
                                }
                            }
                        }
                    }
                    visibleDishes.groupBy { it.category }.forEach { (groupCategory, group) ->
                        Text(groupCategory.label, fontFamily = FontFamily.Serif, fontSize = 25.sp)
                        Spacer(Modifier.height(12.dp))
                        group.chunked(2).forEach { row ->
                            Row(horizontalArrangement = Arrangement.spacedBy(14.dp)) {
                                row.forEach { dish ->
                                    DishCard(dish, selected == dish, dish.name in learned, pending == null,
                                        audioBusy = audioBusy,
                                        audioActive = audioDishName == dish.name,
                                        audioError = audioError?.takeIf { audioErrorDishName == dish.name },
                                        onPronounce = { pronounce(dish) },
                                        modifier = Modifier.weight(1f)) {
                                        selected = dish
                                        error = null
                                    }
                                }
                                if (row.size == 1) Spacer(Modifier.weight(1f))
                            }
                            Spacer(Modifier.height(14.dp))
                        }
                    }
                    Spacer(Modifier.height(10.dp))
                    Surface(color = Color(0xFFEEEADD), shape = RoundedCornerShape(18.dp)) {
                        Column(Modifier.padding(20.dp)) {
                            Text("A LITTLE LOCAL KNOW-HOW", color = Clay, fontSize = 10.sp, letterSpacing = 1.sp)
                            Spacer(Modifier.height(8.dp))
                            Text("In Vienna, there's always time for cake.", fontFamily = FontFamily.Serif, fontSize = 21.sp)
                            Spacer(Modifier.height(6.dp))
                            Text("Ask for “Schlagobers” with your Sachertorte. That's Austrian German for whipped cream.",
                                color = Muted, fontSize = 13.sp, lineHeight = 20.sp)
                            Spacer(Modifier.height(8.dp))
                            Text("“Paradeiser” means “Tomate” (tomato). These Austrian words are used in Vienna too, but aren't all uniquely Viennese.",
                                color = Muted, fontSize = 13.sp, lineHeight = 20.sp)
                        }
                    }
                    Spacer(Modifier.height(20.dp))
                    Text("Made for curious appetites. Inspired by Vienna.", color = Muted, fontSize = 11.sp)
                }
                Surface(
                    modifier = Modifier.width(380.dp).fillMaxHeight(),
                    shape = RoundedCornerShape(24.dp), color = Color.White,
                    border = androidx.compose.foundation.BorderStroke(1.dp, Line),
                ) {
                    Column(Modifier.fillMaxSize()) {
                        Row(Modifier.padding(22.dp), verticalAlignment = Alignment.CenterVertically) {
                            Box(Modifier.size(46.dp).background(Color(0xFFECE4D2), CircleShape), contentAlignment = Alignment.Center) {
                                Text("L", fontFamily = FontFamily.Serif, fontSize = 28.sp, color = Green)
                            }
                            Spacer(Modifier.width(12.dp))
                            Column(Modifier.weight(1f)) {
                                Text("Meet Leni", fontFamily = FontFamily.Serif, fontSize = 23.sp)
                                Text("Your Viennese AI local", color = Muted, fontSize = 12.sp)
                            }
                            Box(Modifier.size(8.dp).background(if (apiKey.isBlank()) Clay else Green, CircleShape))
                        }
                        HorizontalDivider(color = Line)
                        Column(
                            Modifier.weight(1f).verticalScroll(chatScroll).padding(20.dp),
                            verticalArrangement = Arrangement.spacedBy(14.dp),
                        ) {
                            Text("ON THE MENU · ${selected.name.uppercase()}", color = Clay, fontSize = 10.sp, letterSpacing = 1.sp)
                            Bubble("Servus! I'm Leni, your AI guide to Vienna's delicious words. Let's start with ${selected.name}. Ready to give it a go?", false)
                            Surface(color = Cream, shape = RoundedCornerShape(16.dp)) {
                                Column(Modifier.padding(16.dp)) {
                                    Text(selected.name, fontFamily = FontFamily.Serif, fontSize = 23.sp)
                                    Spacer(Modifier.height(6.dp))
                                    Text(selected.pronunciation, color = Clay, fontWeight = FontWeight.Bold, fontSize = 16.sp)
                                    Spacer(Modifier.height(8.dp))
                                    Text(selected.tip, color = Muted, fontSize = 13.sp, lineHeight = 20.sp)
                                    Spacer(Modifier.height(8.dp))
                                    Text(selected.localVocabulary, color = Green, fontSize = 12.sp, lineHeight = 18.sp)
                                    Spacer(Modifier.height(8.dp))
                                    Text("At the table: “${selected.order}”", color = Green, fontSize = 12.sp)
                                    Spacer(Modifier.height(4.dp))
                                    Row {
                                        listOf(false, true).forEach { slow ->
                                            TextButton(
                                                enabled = !audioBusy,
                                                onClick = { pronounce(selected, slow) },
                                            ) { Text(if (slow) "Listen slowly" else "Listen", fontSize = 12.sp) }
                                        }
                                    }
                                    if (audioBusy) {
                                        TextButton(onClick = { audioJob?.cancel(); audio.stop() }) { Text("Stop audio") }
                                    }
                                    Text("Approximate phonetics · Gemini AI voice, prompted with a Viennese accent; pronunciation may vary.",
                                        color = Muted, fontSize = 10.sp, lineHeight = 15.sp)
                                    audioError?.takeIf { audioErrorDishName == selected.name }?.let {
                                        Text(it, color = Clay, fontSize = 12.sp)
                                    }
                                }
                            }
                            if (messages.isEmpty()) {
                                SuggestionChip(onClick = { send("Teach me to pronounce ${selected.name}, step by step.") },
                                    enabled = pending == null, label = { Text("Break it down for me", fontSize = 12.sp) })
                                SuggestionChip(onClick = { send("How do I order ${selected.name} in a Viennese restaurant?") },
                                    enabled = pending == null, label = { Text("Help me order it", fontSize = 12.sp) })
                            }
                            messages.forEach { Bubble(it.text, it.fromUser) }
                            pending?.let {
                                Bubble(it, true)
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    CircularProgressIndicator(Modifier.size(16.dp), strokeWidth = 2.dp)
                                    Spacer(Modifier.width(10.dp))
                                    Text("Leni is thinking…", color = Muted, fontSize = 12.sp)
                                }
                            }
                            error?.let { Text(it, color = MaterialTheme.colorScheme.error, fontSize = 13.sp) }
                            TextButton(onClick = { learned = if (selected.name in learned) learned - selected.name else learned + selected.name }) {
                                Text(if (selected.name in learned) "Practised ✓ · Undo" else "I've practised this dish", fontSize = 12.sp)
                            }
                        }
                        HorizontalDivider(color = Line)
                        Column(Modifier.padding(16.dp)) {
                            OutlinedTextField(
                                value = input, onValueChange = { input = it }, enabled = pending == null,
                                placeholder = { Text("Ask Leni a question…", fontSize = 13.sp) },
                                modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(16.dp), maxLines = 3,
                            )
                            Spacer(Modifier.height(8.dp))
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text("Text coach · $model\nMessages are sent to Google.", color = Muted,
                                    fontSize = 9.sp, lineHeight = 14.sp, modifier = Modifier.weight(1f))
                                Button(onClick = { send(input) }, enabled = pending == null && input.isNotBlank()) {
                                    Text("Send")
                                }
                            }
                        }
                    }
                }
            }
        }
    }
    if (showSettings) {
        SettingsDialog(apiKey, model, speechModel, { showSettings = false }) { key, id, speechId ->
            apiKey = key
            model = id
            speechModel = speechId
            showSettings = false
            error = null
        }
    }
}

@Composable
private fun DishCard(
    dish: Dish, selected: Boolean, learned: Boolean, enabled: Boolean,
    audioBusy: Boolean, audioActive: Boolean, audioError: String?,
    onPronounce: () -> Unit, modifier: Modifier, onClick: () -> Unit,
) {
    val uriHandler = LocalUriHandler.current
    Column(
        modifier.border(if (selected) 2.dp else 1.dp, if (selected) Green else Line, RoundedCornerShape(18.dp))
            .background(Color.White, RoundedCornerShape(18.dp)).clickable(enabled = enabled, onClick = onClick).padding(13.dp),
    ) {
        Image(
            painter = painterResource(dish.photo.resource),
            contentDescription = "A serving of ${dish.name}",
            contentScale = ContentScale.Crop,
            modifier = Modifier.fillMaxWidth().height(145.dp).clip(RoundedCornerShape(12.dp)),
        )
        Spacer(Modifier.height(6.dp))
        Text("Photo: ${dish.photo.author}", color = Muted, fontSize = 10.sp,
            modifier = Modifier.clickable { uriHandler.openUri(dish.photo.source) })
        Text("${dish.photo.license} · displayed cropped", color = Muted, fontSize = 10.sp,
            modifier = Modifier.clickable { uriHandler.openUri(dish.photo.licenseUrl) })
        Spacer(Modifier.height(12.dp))
        Text("${dish.category.label.uppercase()}${if (learned) " · PRACTISED" else ""}",
            color = Clay, fontSize = 9.sp, letterSpacing = 1.sp)
        if (dish.isVegetarian) {
            Spacer(Modifier.height(4.dp))
            Text("Vegetarian", color = Green, fontSize = 11.sp)
        }
        Spacer(Modifier.height(6.dp))
        Text(dish.name, fontFamily = FontFamily.Serif, fontSize = 23.sp, lineHeight = 27.sp)
        Spacer(Modifier.height(6.dp))
        Text(dish.pronunciation, color = Clay, fontWeight = FontWeight.Bold, fontSize = 14.sp)
        Text("Approximate phonetic spelling", color = Muted, fontSize = 10.sp)
        Button(onClick = onPronounce, enabled = !audioBusy) {
            Text(if (audioActive) "Speaking…" else "Listen with Gemini", fontSize = 12.sp)
        }
        audioError?.let { Text(it, color = MaterialTheme.colorScheme.error, fontSize = 12.sp) }
        Spacer(Modifier.height(8.dp))
        DishFact("LOCAL NAME", dish.dialectName ?: "The same dish name is used in Vienna.")
        Spacer(Modifier.height(8.dp))
        DishFact("AUSTRIAN WORDS", dish.localVocabulary)
        Spacer(Modifier.height(12.dp))
        Text(dish.description, color = Muted, fontSize = 12.sp, lineHeight = 18.sp)
        Spacer(Modifier.height(12.dp))
        DishFact("MADE WITH", dish.ingredients)
        Spacer(Modifier.height(10.dp))
        DishFact("FROM", dish.origin)
        Spacer(Modifier.height(10.dp))
        DishFact("WHEN TO ENJOY", dish.occasion)
        Spacer(Modifier.height(12.dp))
        Text(if (selected) "Learning this dish →" else "Learn to say it →", color = Green, fontSize = 12.sp, fontWeight = FontWeight.Medium)
    }
}

@Composable
private fun DishFact(label: String, text: String) {
    Text(label, color = Clay, fontSize = 9.sp, letterSpacing = 1.sp, fontWeight = FontWeight.Medium)
    Spacer(Modifier.height(3.dp))
    Text(text, color = Muted, fontSize = 12.sp, lineHeight = 18.sp)
}

@Composable
private fun Bubble(text: String, user: Boolean) {
    Row(Modifier.fillMaxWidth(), horizontalArrangement = if (user) Arrangement.End else Arrangement.Start) {
        Surface(color = if (user) Green else Cream, shape = RoundedCornerShape(16.dp)) {
            Text(text, modifier = Modifier.padding(14.dp), color = if (user) Color.White else Ink, fontSize = 13.sp, lineHeight = 21.sp)
        }
    }
}

@Composable
private fun SettingsDialog(
    key: String, model: String, speechModel: String, dismiss: () -> Unit,
    save: (String, String, String) -> Unit,
) {
    var draftKey by remember { mutableStateOf(key) }
    var draftModel by remember { mutableStateOf(model) }
    var draftSpeechModel by remember { mutableStateOf(speechModel) }
    var attemptedSave by remember { mutableStateOf(false) }
    val keyError = apiKeyValidationError(draftKey)
    val modelError = modelValidationError(draftModel.trim())
    val speechModelError = modelValidationError(draftSpeechModel.trim())
    AlertDialog(
        onDismissRequest = dismiss,
        title = { Text("Meet your AI local", fontFamily = FontFamily.Serif) },
        text = {
            Column(
                modifier = Modifier.heightIn(max = 450.dp).verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(14.dp),
            ) {
                Text("Use a Gemini API key from Google AI Studio. It stays in memory for this session; it is never saved to disk.")
                OutlinedTextField(draftKey, { draftKey = it }, label = { Text("Gemini API key") },
                    singleLine = true, visualTransformation = PasswordVisualTransformation(),
                    isError = attemptedSave && keyError != null,
                    supportingText = { if (attemptedSave) keyError?.let { Text(it) } })
                OutlinedTextField(draftModel, { draftModel = it }, label = { Text("Model ID") }, singleLine = true,
                    isError = attemptedSave && modelError != null,
                    supportingText = { if (attemptedSave) modelError?.let { Text(it) } })
                OutlinedTextField(draftSpeechModel, { draftSpeechModel = it }, label = { Text("Speech model ID") }, singleLine = true,
                    isError = attemptedSave && speechModelError != null,
                    supportingText = { if (attemptedSave) speechModelError?.let { Text(it) } })
                Text("Default: gemini-3.5-flash. Availability depends on your account. Errors are shown without silently switching models.",
                    color = Muted, fontSize = 12.sp)
                Text("Speech uses $DEFAULT_SPEECH_MODEL with the Aoede voice. Use a speech-capable Gemini model; the text-coach model is separate.",
                    color = Muted, fontSize = 12.sp)
                Text("Questions, conversation history and speech prompts are sent to Google. Audio is generated by Gemini and played locally. Leni cannot hear you.",
                    color = Muted, fontSize = 12.sp)
            }
        },
        confirmButton = {
            TextButton(onClick = {
                attemptedSave = true
                if (keyError == null && modelError == null && speechModelError == null) {
                    save(draftKey.trim(), draftModel.trim(), draftSpeechModel.trim())
                }
            }) { Text("Save for this session") }
        },
        dismissButton = { TextButton(onClick = dismiss) { Text("Cancel") } },
    )
}
