package at.wien.wordofmouth

import javax.sound.sampled.AudioFormat
import javax.sound.sampled.AudioSystem
import javax.sound.sampled.LineUnavailableException
import javax.sound.sampled.SourceDataLine
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.currentCoroutineContext
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.withContext

class PronunciationAudio {
    @Volatile private var activeLine: SourceDataLine? = null

    suspend fun play(audio: SpeechAudio) = withContext(Dispatchers.IO) {
        currentCoroutineContext().ensureActive()
        val line = try {
            AudioSystem.getSourceDataLine(AudioFormat(audio.sampleRate.toFloat(), 16, 1, true, false))
        } catch (_: IllegalArgumentException) {
            throw CoachException("Your audio device doesn't support this speech format.")
        } catch (_: LineUnavailableException) {
            throw CoachException("Your audio device is unavailable. Check your sound settings.")
        }
        activeLine = line
        try {
            line.open(AudioFormat(audio.sampleRate.toFloat(), 16, 1, true, false))
            currentCoroutineContext().ensureActive()
            line.start()
            var offset = 0
            while (offset < audio.bytes.size) {
                currentCoroutineContext().ensureActive()
                val written = line.write(audio.bytes, offset, minOf(4096, audio.bytes.size - offset))
                if (written <= 0) throw CoachException("Audio playback stopped before the pronunciation finished.")
                offset += written
            }
            line.drain()
        } catch (_: LineUnavailableException) {
            throw CoachException("Couldn't open your audio device. Check your sound settings.")
        } catch (_: IllegalArgumentException) {
            throw CoachException("Your audio device couldn't play this speech format.")
        } catch (_: IllegalStateException) {
            currentCoroutineContext().ensureActive()
            throw CoachException("Your audio device stopped playback unexpectedly.")
        } finally {
            line.close()
            activeLine = null
        }
    }

    fun stop() {
        activeLine?.close()
    }
}
