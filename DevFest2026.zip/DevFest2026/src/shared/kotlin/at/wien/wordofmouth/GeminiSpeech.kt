package at.wien.wordofmouth

import java.io.ByteArrayOutputStream
import java.net.URI
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.util.Base64
import okhttp3.OkHttpClient

internal const val DEFAULT_SPEECH_MODEL = "gemini-3.8-flash-tts"

class GeminiSpeech(
    endpoint: URI = URI.create("https://generativelanguage.googleapis.com/v1beta/"),
    http: OkHttpClient = geminiHttpClient(),
) {
    private val api = GeminiApi(endpoint, http)

    suspend fun generate(apiKey: String, model: String, dish: Dish, slow: Boolean): SpeechAudio {
        val prompt = """
            You are a friendly Viennese local helping a visitor pronounce a dish name.
            Speak in natural Austrian German with a gentle Viennese accent, warmly and clearly,
            without exaggerating the dialect. ${if (slow) "Speak slowly with a brief pause between repetitions." else "Speak at a relaxed conversational pace."}
            Read only the following dish name twice. Do not read these instructions or add explanations:
            ${dish.name}
        """.trimIndent()
        val response = api.generate(
            apiKey, model,
            GenerateRequest(
                contents = listOf(Content("user", listOf(Part(prompt)))),
                generationConfig = GenerationConfig(
                    responseModalities = listOf("AUDIO"),
                    speechConfig = SpeechConfig(VoiceConfig(PrebuiltVoiceConfig("Aoede"))),
                ),
            ),
        )
        val audioParts = response.candidates.firstOrNull()?.content?.parts.orEmpty()
            .filter { !it.thought }.mapNotNull { it.inlineData }
        if (audioParts.isEmpty()) throw CoachException("Gemini returned no audio. Check the speech model in Settings and try again.")
        val decoded = audioParts.map { decodeSpeechAudio(it) }
        val sampleRate = decoded.first().sampleRate
        if (decoded.any { it.sampleRate != sampleRate }) {
            throw CoachException("Gemini returned incompatible audio chunks. Please try again.")
        }
        val bytes = ByteArrayOutputStream()
        decoded.forEach { bytes.write(it.bytes) }
        return SpeechAudio(bytes.toByteArray(), sampleRate)
    }
}

data class SpeechAudio(val bytes: ByteArray, val sampleRate: Int)

internal fun decodeSpeechAudio(data: InlineData): SpeechAudio {
    val bytes = try {
        Base64.getDecoder().decode(data.data)
    } catch (_: IllegalArgumentException) {
        throw CoachException("Gemini returned invalid audio data. Please try again.")
    }
    if (bytes.isEmpty()) throw CoachException("Gemini returned empty audio. Please try again.")
    val mime = data.mimeType.substringBefore(';').trim().lowercase()
    val hasWaveHeader = bytes.size >= 12 && bytes.copyOfRange(0, 4).contentEquals("RIFF".toByteArray()) &&
        bytes.copyOfRange(8, 12).contentEquals("WAVE".toByteArray())
    if (mime in listOf("audio/wav", "audio/x-wav", "audio/wave") ||
        (hasWaveHeader && mime in listOf("audio/l16", "audio/pcm"))) {
        return decodeWave(bytes)
    }
    if (mime !in listOf("audio/l16", "audio/pcm")) {
        throw CoachException("Gemini returned an unsupported audio format: ${data.mimeType}.")
    }
    val parameters = data.mimeType.split(';').drop(1).associate { parameter ->
        parameter.substringBefore('=').trim().lowercase() to parameter.substringAfter('=', "").trim()
    }
    val rate = parameters["rate"]?.toIntOrNull() ?: if ("rate" !in parameters) 24000 else 0
    val channels = parameters["channels"]?.toIntOrNull() ?: if ("channels" !in parameters) 1 else 0
    if (rate !in 8000..48000 || channels != 1 || bytes.size % 2 != 0 ||
        parameters["codec"]?.lowercase()?.let { it != "pcm" } == true) {
        throw CoachException("Gemini returned an unsupported PCM audio format.")
    }
    // Gemini's inline L16 payload is signed little-endian PCM, unlike network L16.
    return SpeechAudio(bytes, rate)
}

private fun decodeWave(bytes: ByteArray): SpeechAudio {
    fun invalid(): Nothing = throw CoachException("Gemini returned an unreadable or unsupported WAV file.")
    fun tag(offset: Int) = String(bytes, offset, 4, Charsets.US_ASCII)
    if (bytes.size < 12 || tag(0) != "RIFF" || tag(8) != "WAVE") invalid()
    val buffer = ByteBuffer.wrap(bytes).order(ByteOrder.LITTLE_ENDIAN)
    val declaredSize = buffer.getInt(4).toLong() and 0xffffffffL
    if (declaredSize + 8 != bytes.size.toLong()) invalid()
    var offset = 12
    var rate: Int? = null
    var samples: ByteArray? = null
    while (offset < bytes.size) {
        if (bytes.size - offset < 8) invalid()
        val chunkSize = buffer.getInt(offset + 4).toLong() and 0xffffffffL
        val start = offset + 8
        val end = start.toLong() + chunkSize
        if (end > bytes.size) invalid()
        when (tag(offset)) {
            "fmt " -> {
                if (chunkSize < 16 || rate != null) invalid()
                val encoding = buffer.getShort(start).toInt()
                val channels = buffer.getShort(start + 2).toInt()
                val sampleRate = buffer.getInt(start + 4)
                val byteRate = buffer.getInt(start + 8)
                val blockAlign = buffer.getShort(start + 12).toInt()
                val bits = buffer.getShort(start + 14).toInt()
                if (encoding != 1 || channels != 1 || bits != 16 || sampleRate !in 8000..48000 ||
                    blockAlign != 2 || byteRate != sampleRate * 2) invalid()
                rate = sampleRate
            }
            "data" -> {
                if (samples != null || chunkSize == 0L || chunkSize % 2 != 0L) invalid()
                samples = bytes.copyOfRange(start, end.toInt())
            }
        }
        val paddedEnd = end + chunkSize % 2
        if (paddedEnd > bytes.size) invalid()
        offset = paddedEnd.toInt()
    }
    return SpeechAudio(samples ?: invalid(), rate ?: invalid())
}
