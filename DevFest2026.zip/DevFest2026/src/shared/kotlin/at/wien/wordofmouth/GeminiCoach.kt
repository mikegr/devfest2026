package at.wien.wordofmouth

import java.io.IOException
import java.net.URI
import java.util.concurrent.TimeUnit
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.withContext
import kotlinx.serialization.Serializable
import kotlinx.serialization.encodeToString
import kotlinx.serialization.json.Json
import okhttp3.Call
import okhttp3.Callback
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import okhttp3.Response
import kotlin.coroutines.resumeWithException

data class ChatMessage(val text: String, val fromUser: Boolean)

class CoachException(message: String) : Exception(message)

internal fun apiKeyValidationError(key: String): String? = when {
    key.isBlank() -> "Enter your Gemini API key."
    key.trim().any { it.code !in 33..126 } -> "The key contains spaces or unsupported characters. Paste only the API key."
    else -> null
}

internal fun modelValidationError(model: String): String? =
    if (model.matches(Regex("[a-zA-Z0-9._-]+"))) null
    else "Enter a model ID such as gemini-3.5-flash, without a URL or spaces."

class GeminiCoach(
    private val endpoint: URI = URI.create("https://generativelanguage.googleapis.com/v1beta/"),
    private val http: OkHttpClient = geminiHttpClient(),
) {
    private val api = GeminiApi(endpoint, http)

    suspend fun reply(apiKey: String, model: String, dish: Dish, messages: List<ChatMessage>): String {
        val prompt = """
                You are Leni, a friendly Viennese local and pronunciation tutor, not a real human.
                Speak mainly in English with occasional Austrian greetings explained in English.
                Teach Austrian German dish names accurately and warmly, without caricaturing the accent.
                The learner is exploring ${dish.name}: ${dish.description}
                Ingredients: ${dish.ingredients}
                Origins: ${dish.origin}
                Typical eating occasions: ${dish.occasion}
                Local vocabulary: ${dish.localVocabulary}
                Local dish name: ${dish.dialectName ?: "The same name is used in Vienna."}
                Give short, conversational replies (under 160 words). When teaching a dish, give a
                syllable breakdown, mark stress with capitals, give IPA if confident, explain tricky
                sounds, and give a natural ordering phrase with an English translation.
                English sound approximations are only approximations. Explain regional variations
                when relevant. Invite the learner to say it aloud, but never claim to hear or assess
                their voice: this is text chat. Treat typed pronunciation attempts as text only.
                Focus on Viennese food and pronunciation. Do not use markdown tables.
            """.trimIndent()
        val body = GenerateRequest(
            systemInstruction = Content(parts = listOf(Part(prompt))),
            contents = messages.map {
                Content(if (it.fromUser) "user" else "model", listOf(Part(it.text)))
            },
        )
        val result = api.generate(apiKey, model, body)
        return result.candidates.firstOrNull()?.content?.parts?.filter { !it.thought }?.mapNotNull { it.text }
            ?.joinToString("\n")?.trim()?.takeIf { it.isNotEmpty() }
            ?: throw CoachException("Gemini returned no text. Please try another question.")
    }
}

internal class GeminiApi(
    private val endpoint: URI,
    private val http: OkHttpClient,
) {
    private val json = Json { ignoreUnknownKeys = true }

    suspend fun generate(apiKey: String, model: String, body: GenerateRequest): GenerateResponse =
        withContext(Dispatchers.IO) {
            apiKeyValidationError(apiKey)?.let { throw CoachException(it) }
            modelValidationError(model)?.let { throw CoachException(it) }
            val request = Request.Builder()
                .url(endpoint.resolve("models/$model:generateContent").toString())
                .header("x-goog-api-key", apiKey.trim())
                .post(json.encodeToString(body).toRequestBody("application/json".toMediaType()))
                .build()
            val response = try {
                http.newCall(request).awaitResponse()
            } catch (_: IOException) {
                throw CoachException("Couldn't reach Gemini. Check your connection and try again.")
            }
            if (response.code !in 200..299) {
                val reason = when (response.code) {
                    400 -> "Gemini rejected this request. Check the model ID and your API key."
                    401, 403 -> "Gemini couldn't authorize this key. Check its API access in Settings."
                    404 -> "The model '$model' is unavailable for this key. Check its availability or change it in Settings."
                    429 -> "Gemini's quota is exhausted or busy. Wait a moment, then try again."
                    else -> "Gemini returned HTTP ${response.code}. Please try again later."
                }
                throw CoachException(reason)
            }
            val result = try {
                json.decodeFromString<GenerateResponse>(response.body)
            } catch (_: kotlinx.serialization.SerializationException) {
                throw CoachException("Gemini returned an unreadable response. Please try again.")
            }
            if (result.promptFeedback?.blockReason != null) {
                throw CoachException("Gemini blocked this prompt. Try a different pronunciation question.")
            }
            val candidate = result.candidates.firstOrNull()
            if (candidate?.finishReason !in listOf("STOP", "MAX_TOKENS", null)) {
                throw CoachException("Gemini couldn't complete this reply. Try rephrasing your question.")
            }
            result
        }
}

internal fun geminiHttpClient(): OkHttpClient = OkHttpClient.Builder()
    .connectTimeout(15, TimeUnit.SECONDS)
    .callTimeout(60, TimeUnit.SECONDS)
    .build()

private data class GeminiHttpResponse(val code: Int, val body: String)

private suspend fun Call.awaitResponse(): GeminiHttpResponse = suspendCancellableCoroutine { continuation ->
    continuation.invokeOnCancellation { cancel() }
    enqueue(object : Callback {
        override fun onFailure(call: Call, e: IOException) {
            if (continuation.isActive) continuation.resumeWithException(e)
        }

        override fun onResponse(call: Call, response: Response) {
            try {
                response.use {
                    val result = GeminiHttpResponse(response.code, response.body.string())
                    continuation.resume(result) { _, _, _ -> }
                }
            } catch (error: IOException) {
                if (continuation.isActive) continuation.resumeWithException(error)
            }
        }
    })
}

@Serializable
internal data class GenerateRequest(
    val systemInstruction: Content? = null,
    val contents: List<Content>,
    val generationConfig: GenerationConfig = GenerationConfig(),
)

@Serializable
internal data class GenerationConfig(
    val temperature: Double = 0.7,
    val maxOutputTokens: Int = 2048,
    val responseModalities: List<String>? = null,
    val speechConfig: SpeechConfig? = null,
)

@Serializable
internal data class SpeechConfig(val voiceConfig: VoiceConfig)

@Serializable
internal data class VoiceConfig(val prebuiltVoiceConfig: PrebuiltVoiceConfig)

@Serializable
internal data class PrebuiltVoiceConfig(val voiceName: String)

@Serializable
internal data class Content(val role: String? = null, val parts: List<Part> = emptyList())

@Serializable
internal data class Part(
    val text: String? = null,
    val thought: Boolean = false,
    val inlineData: InlineData? = null,
)

@Serializable
internal data class InlineData(val mimeType: String, val data: String)

@Serializable
internal data class GenerateResponse(
    val candidates: List<Candidate> = emptyList(),
    val promptFeedback: PromptFeedback? = null,
)

@Serializable
internal data class Candidate(val content: Content? = null, val finishReason: String? = null)

@Serializable
internal data class PromptFeedback(val blockReason: String? = null)
