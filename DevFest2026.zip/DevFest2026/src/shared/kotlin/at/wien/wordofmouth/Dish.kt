package at.wien.wordofmouth

data class Dish(
    val name: String,
    val category: DishCategory,
    val description: String,
    val pronunciation: String,
    val tip: String,
    val order: String,
    val ingredients: String,
    val origin: String,
    val occasion: String,
    val photo: DishPhoto,
    val isVegetarian: Boolean,
    val localVocabulary: String,
    val dialectName: String? = null,
)

enum class DishCategory(val label: String) {
    MAIN_DISHES("Main dishes"),
    SOUPS("Soups"),
    DESSERTS("Desserts"),
    PASTRIES("Pastries"),
    STREET_FOOD("Street food"),
    DRINKS("Drinks"),
}

data class DishPhoto(
    val resource: String,
    val author: String,
    val source: String,
    val license: String,
    val licenseUrl: String,
)

val dishes = listOf(
    Dish(
        "Wiener Schnitzel", DishCategory.MAIN_DISHES,
        "Golden, paper-thin veal with a crisp, airy crumb. A true Viennese classic.",
        "VEE-ner SHNIT-sel",
        "German W sounds like English V. Start Schnitzel with “sh”, not “sk”.",
        "Ein Wiener Schnitzel, bitte.",
        "Thin veal coated in flour, egg and breadcrumbs, then pan-fried; usually served with lemon and potato salad.",
        "A hallmark of Viennese cuisine. Its exact origins are debated; the popular story of an import from Milan is not firmly established.",
        "A lunch or dinner main course, especially for Sunday family meals and restaurant outings.",
        DishPhoto(
            "images/wiener-schnitzel.jpg", "Kobako",
            "https://commons.wikimedia.org/wiki/File:Wiener-Schnitzel02.jpg",
            "CC BY-SA 2.5", "https://creativecommons.org/licenses/by-sa/2.5/",
        ),
        isVegetarian = false,
        localVocabulary = "Erdäpfel = Kartoffeln (potatoes), as in Erdäpfelsalat. The dish itself is still Wiener Schnitzel.",
    ),
    Dish(
        "Kaiserschmarrn", DishCategory.DESSERTS,
        "Fluffy shredded pancakes, a snowfall of sugar, and plum compote on the side.",
        "KAI-zer-shmarn",
        "KAI rhymes with “eye”. Keep the final “shmarn” together as one syllable.",
        "Einmal Kaiserschmarrn, bitte.",
        "Eggs, milk, flour and sugar make a thick pancake, fried in butter and torn into pieces. Often includes raisins.",
        "An Austrian dish associated with Emperor Franz Joseph I. Stories about its invention vary.",
        "As a dessert or a sweet main meal, especially for lunch at an Alpine mountain hut; often with plum compote or apple sauce.",
        DishPhoto(
            "images/kaiserschmarrn.jpg", "Takeaway",
            "https://commons.wikimedia.org/wiki/File:2015_0731_Kaiserschmarrn_Apfelso%C3%9Fe_Edelweissh%C3%BCtte_S%C3%B6lden.jpg",
            "CC BY-SA 4.0", "https://creativecommons.org/licenses/by-sa/4.0/",
        ),
        isVegetarian = true,
        localVocabulary = "Zwetschken = a type of Pflaumen (plums), used in the traditional Zwetschkenröster compote.",
    ),
    Dish(
        "Tafelspitz", DishCategory.MAIN_DISHES,
        "Tender boiled beef, fragrant broth, and a little apple horseradish. Imperial comfort food.",
        "TAH-fel-shpits",
        "Stress TAH. German “sp” at the start of Spitz sounds like “shp”.",
        "Ich hätte gern Tafelspitz.",
        "A cut of beef gently simmered with root vegetables and spices; served with potatoes, apple horseradish and often chive sauce.",
        "Rooted in Vienna's boiled-beef tradition and famously enjoyed by Emperor Franz Joseph I.",
        "A hearty lunch or dinner, often for Sunday gatherings, special family meals or a traditional Viennese restaurant visit.",
        DishPhoto(
            "images/tafelspitz.jpg", "RobertK",
            "https://commons.wikimedia.org/wiki/File:Tafelspitz.jpg",
            "CC BY-SA 2.5", "https://creativecommons.org/licenses/by-sa/2.5/",
        ),
        isVegetarian = false,
        localVocabulary = "Kren = Meerrettich (horseradish). Apfelkren is the apple-and-horseradish accompaniment.",
    ),
    Dish(
        "Sachertorte", DishCategory.DESSERTS,
        "Rich chocolate cake, a whisper of apricot jam, and a spoonful of whipped cream.",
        "ZAH-kher-TOR-teh",
        "Start with a soft Z. The “ch” is a gentle throaty sound, not the “ch” in cheese.",
        "Ein Stück Sachertorte, bitte.",
        "Chocolate sponge made with eggs, butter, flour and sugar, layered with apricot jam and covered in chocolate glaze.",
        "Created in Vienna by Franz Sacher in 1832; closely associated with the Hotel Sacher and Demel.",
        "A slice with afternoon coffee at a café, at celebrations or as a dessert, traditionally with unsweetened whipped cream.",
        DishPhoto(
            "images/sachertorte.jpg", "David Monniaux",
            "https://commons.wikimedia.org/wiki/File:Sachertorte_DSC03027.JPG",
            "CC BY-SA 3.0", "https://creativecommons.org/licenses/by-sa/3.0/",
        ),
        isVegetarian = true,
        localVocabulary = "Schlagobers = Schlagsahne (whipped cream); Marille = Aprikose (apricot), used in the jam.",
    ),
)

internal fun filterDishes(
    collection: List<Dish>,
    category: DishCategory?,
    vegetarianOnly: Boolean,
    query: String,
): List<Dish> {
    val search = query.trim()
    return collection.filter { dish ->
        (category == null || dish.category == category) &&
            (!vegetarianOnly || dish.isVegetarian) &&
            (search.isEmpty() || listOf(dish.name, dish.description, dish.ingredients, dish.category.label,
                dish.localVocabulary, dish.dialectName.orEmpty())
                .any { it.contains(search, ignoreCase = true) })
    }
}
