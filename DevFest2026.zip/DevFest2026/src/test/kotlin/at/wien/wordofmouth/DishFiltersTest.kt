package at.wien.wordofmouth

import kotlin.test.Test
import kotlin.test.assertEquals
import kotlin.test.assertTrue

class DishFiltersTest {
    @Test
    fun `category and vegetarian filters are combined rather than replacing each other`() {
        assertTrue(filterDishes(dishes, DishCategory.MAIN_DISHES, true, "").isEmpty())
        assertEquals(
            listOf("Kaiserschmarrn", "Sachertorte"),
            filterDishes(dishes, DishCategory.DESSERTS, true, "").map { it.name },
        )
        assertEquals(
            listOf("Wiener Schnitzel", "Tafelspitz"),
            filterDishes(dishes, DishCategory.MAIN_DISHES, false, "").map { it.name },
        )
    }

    @Test
    fun `search ignores case and surrounding whitespace and finds names and ingredients`() {
        assertEquals(listOf("Wiener Schnitzel"), filterDishes(dishes, null, false, "  SCHNITZEL  ").map { it.name })
        assertEquals(listOf("Sachertorte"), filterDishes(dishes, null, false, "apricot").map { it.name })
        assertEquals(listOf("Tafelspitz"), filterDishes(dishes, null, false, "root vegetables").map { it.name })
    }

    @Test
    fun `search respects category and vegetarian constraints`() {
        assertTrue(filterDishes(dishes, DishCategory.DESSERTS, false, "Schnitzel").isEmpty())
        assertTrue(filterDishes(dishes, null, true, "beef").isEmpty())
        assertEquals(listOf("Sachertorte"), filterDishes(dishes, DishCategory.DESSERTS, true, "chocolate").map { it.name })
    }

    @Test
    fun `Austrian vocabulary and an alternate local dish name are searchable`() {
        assertEquals(listOf("Tafelspitz"), filterDishes(dishes, null, false, "Kren").map { it.name })
        assertEquals(listOf("Sachertorte"), filterDishes(dishes, null, true, "Schlagobers").map { it.name })
        val localDish = dishes.first().copy(dialectName = "Local test name")
        assertEquals(listOf(localDish), filterDishes(listOf(localDish), null, false, "local test"))
    }

    @Test
    fun `empty categories and unmatched searches return no results and clearing restores collection`() {
        assertTrue(filterDishes(dishes, DishCategory.SOUPS, false, "").isEmpty())
        assertTrue(filterDishes(dishes, null, false, "not on the menu").isEmpty())
        assertEquals(dishes, filterDishes(dishes, null, false, "  "))
    }
}
