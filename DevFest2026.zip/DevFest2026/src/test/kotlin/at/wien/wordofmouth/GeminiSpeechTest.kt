package at.wien.wordofmouth

import com.sun.net.httpserver.HttpServer
import java.io.ByteArrayInputStream
import java.io.ByteArrayOutputStream
import java.net.InetSocketAddress
import java.net.URI
import java.util.Base64
import javax.sound.sampled.AudioFileFormat
import javax.sound.sampled.AudioFormat
import javax.sound.sampled.AudioInputStream
import javax.sound.sampled.AudioSystem
import kotlinx.coroutines.runBlocking
import kotlinx.serialization.json.*
import kotlin.test.Test
import kotlin.test.assertContentEquals
import kotlin.test.assertEquals
import kotlin.test.assertFailsWith
import kotlin.test.assertTrue

class GeminiSpeechTest {
    private val samples = byteArrayOf(0, 0, 1, 0, -1, 127, 0, -128)

    private fun withServer(status: Int, body: String, test: (GeminiSpeech, () -> JsonObject) -> Unit) {
        var requestBody = ""
        var requestKey: String? = null
        var requestQuery: String? = null
        val server = HttpServer.create(InetSocketAddress("127.0.0.1", 0), 0)
        server.createContext("/v1beta/models/$DEFAULT_SPEECH_MODEL:generateContent") { exchange ->
            requestKey = exchange.requestHeaders.getFirst("x-goog-api-key")
            requestQuery = exchange.requestURI.query
            requestBody = exchange.requestBody.bufferedReader().use { it.readText() }
            val bytes = body.toByteArray()
            exchange.sendResponseHeaders(status, bytes.size.toLong())
            exchange.responseBody.use { it.write(bytes) }
        }
        server.start()
        try {
            test(GeminiSpeech(URI.create("http://127.0.0.1:${server.address.port}/v1beta/"))) {
                Json.parseToJsonElement(requestBody).jsonObject
            }
            assertEquals("test-key", requestKey)
            assertEquals(null, requestQuery)
        } finally {
            server.stop(0)
        }
    }

    @Test
    fun `speech requests Austrian German voice and slow pace and decodes PCM without changing samples`() {
        val encoded = Base64.getEncoder().encodeToString(samples)
        val body = """{"candidates":[{"finishReason":"STOP","content":{"parts":[{"inlineData":{"mimeType":"audio/L16;codec=pcm;rate=24000","data":"$encoded"}}]}}]}"""
        withServer(200, body) { speech, request ->
            val audio = runBlocking { speech.generate("test-key", DEFAULT_SPEECH_MODEL, dishes.first(), true) }
            val config = request().getValue("generationConfig").jsonObject
            assertEquals("AUDIO", config.getValue("responseModalities").jsonArray.single().jsonPrimitive.content)
            assertEquals("Aoede", config.getValue("speechConfig").jsonObject.getValue("voiceConfig")
                .jsonObject.getValue("prebuiltVoiceConfig").jsonObject.getValue("voiceName").jsonPrimitive.content)
            val prompt = request().getValue("contents").jsonArray.single().jsonObject.getValue("parts")
                .jsonArray.single().jsonObject.getValue("text").jsonPrimitive.content
            assertTrue(prompt.contains("Austrian German"))
            assertTrue(prompt.contains("Viennese accent"))
            assertTrue(prompt.contains("Speak slowly"))
            assertTrue(prompt.contains("Wiener Schnitzel"))
            assertContentEquals(samples, audio.bytes)
            assertEquals(24000, audio.sampleRate)
        }
    }

    @Test
    fun `WAV headers are decoded rather than played as samples even with an L16 MIME type`() {
        listOf("audio/wav", "audio/L16;rate=24000").forEach { mime ->
            val audio = decodeSpeechAudio(InlineData(mime, Base64.getEncoder().encodeToString(waveBytes())))
            assertContentEquals(samples, audio.bytes)
            assertEquals(24000, audio.sampleRate)
        }
    }

    private fun waveBytes(): ByteArray {
        val output = ByteArrayOutputStream()
        val format = AudioFormat(24000f, 16, 1, true, false)
        AudioInputStream(ByteArrayInputStream(samples), format, (samples.size / 2).toLong()).use {
            AudioSystem.write(it, AudioFileFormat.Type.WAVE, output)
        }
        return output.toByteArray()
    }

    @Test
    fun `portable WAV decoder skips padded metadata and rejects malformed chunks`() {
        val wave = waveBytes()
        val junk = byteArrayOf('J'.code.toByte(), 'U'.code.toByte(), 'N'.code.toByte(), 'K'.code.toByte(), 1, 0, 0, 0, 7, 0)
        val withMetadata = wave.copyOfRange(0, 36) + junk + wave.copyOfRange(36, wave.size)
        java.nio.ByteBuffer.wrap(withMetadata).order(java.nio.ByteOrder.LITTLE_ENDIAN).putInt(4, withMetadata.size - 8)
        assertContentEquals(samples, decodeSpeechAudio(InlineData("audio/wav",
            Base64.getEncoder().encodeToString(withMetadata))).bytes)
        val invalid = listOf(
            wave.copyOf(wave.size - 1),
            wave.copyOf().apply { this[22] = 2 },
            wave.copyOf().apply { this[34] = 8 },
            wave.copyOf().apply { this[12] = 'x'.code.toByte() },
            wave.copyOf().apply { java.nio.ByteBuffer.wrap(this).order(java.nio.ByteOrder.LITTLE_ENDIAN).putInt(40, Int.MAX_VALUE) },
        )
        invalid.forEach {
            assertFailsWith<CoachException> {
                decodeSpeechAudio(InlineData("audio/wav", Base64.getEncoder().encodeToString(it)))
            }
        }
    }

    @Test
    fun `malformed audio and unsupported formats are explicit errors`() {
        val encoded = Base64.getEncoder().encodeToString(samples)
        listOf(
            InlineData("audio/L16;rate=24000", "not base64!"),
            InlineData("audio/L16;rate=24000", ""),
            InlineData("audio/mp3", encoded),
            InlineData("audio/L16;rate=invalid", encoded),
            InlineData("audio/L16;channels=2", encoded),
            InlineData("audio/L16;codec=other", encoded),
            InlineData("audio/L16", Base64.getEncoder().encodeToString(byteArrayOf(1))),
            InlineData("audio/wav", encoded),
        ).forEach { data ->
            assertFailsWith<CoachException> { decodeSpeechAudio(data) }
        }
    }

    @Test
    fun `speech API errors and text-only responses never fall back to a system voice`() {
        listOf(
            404 to "{}",
            429 to "{}",
            200 to """{"promptFeedback":{"blockReason":"SAFETY"}}""",
            200 to """{"candidates":[{"finishReason":"STOP","content":{"parts":[{"text":"Wiener Schnitzel"}]}}]}""",
        ).forEach { (status, body) ->
            withServer(status, body) { speech, _ ->
                assertFailsWith<CoachException> {
                    runBlocking { speech.generate("test-key", DEFAULT_SPEECH_MODEL, dishes.first(), false) }
                }
            }
        }
    }
}
