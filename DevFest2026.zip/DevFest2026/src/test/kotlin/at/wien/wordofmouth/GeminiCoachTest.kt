package at.wien.wordofmouth

import com.sun.net.httpserver.HttpServer
import java.net.InetSocketAddress
import java.net.URI
import java.util.concurrent.CountDownLatch
import java.util.concurrent.TimeUnit
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.cancelAndJoin
import kotlinx.coroutines.launch
import kotlinx.coroutines.runBlocking
import kotlinx.coroutines.withContext
import kotlinx.coroutines.withTimeout
import kotlinx.serialization.json.*
import kotlin.test.Test
import kotlin.test.assertEquals
import kotlin.test.assertFailsWith
import kotlin.test.assertFalse
import kotlin.test.assertNull
import kotlin.test.assertTrue

class GeminiCoachTest {
    private fun withServer(status: Int, body: String, test: (GeminiCoach, () -> JsonObject, () -> String) -> Unit) {
        var requestBody = ""
        var apiKey = ""
        val server = HttpServer.create(InetSocketAddress("127.0.0.1", 0), 0)
        server.createContext("/v1beta/models/gemini-3.5-flash:generateContent") { exchange ->
            requestBody = exchange.requestBody.bufferedReader().use { it.readText() }
            apiKey = exchange.requestHeaders.getFirst("x-goog-api-key")
            val bytes = body.toByteArray()
            exchange.sendResponseHeaders(status, bytes.size.toLong())
            exchange.responseBody.use { it.write(bytes) }
        }
        server.start()
        try {
            val coach = GeminiCoach(URI.create("http://127.0.0.1:${server.address.port}/v1beta/"))
            test(coach, { Json.parseToJsonElement(requestBody).jsonObject }, { apiKey })
        } finally {
            server.stop(0)
        }
    }

    @Test
    fun `sends tutor instruction and conversational roles and reads visible text only`() {
        withServer(200, """{"candidates":[{"content":{"parts":[{"text":"private reasoning","thought":true},{"text":"Servus! Try VEE-ner."}]},"finishReason":"STOP"}]}""") { coach, request, key ->
            val history = listOf(ChatMessage("Hello", true), ChatMessage("Servus!", false), ChatMessage("How do I say it?", true))
            val reply = runBlocking { coach.reply("test-key", "gemini-3.5-flash", dishes.first(), history) }
            assertEquals("Servus! Try VEE-ner.", reply)
            assertEquals("test-key", key())
            assertFalse(request().toString().contains("test-key"))
            val roles = request()["contents"]!!.jsonArray.map { it.jsonObject["role"]!!.jsonPrimitive.content }
            assertEquals(listOf("user", "model", "user"), roles)
            val instruction = request()["systemInstruction"]!!.jsonObject["parts"]!!.jsonArray.first()
                .jsonObject["text"]!!.jsonPrimitive.content
            assertTrue(instruction.contains("Wiener Schnitzel"))
            assertTrue(instruction.contains("never claim to hear"))
            assertTrue(instruction.contains(dishes.first().ingredients))
            assertTrue(instruction.contains(dishes.first().origin))
            assertTrue(instruction.contains(dishes.first().occasion))
        }
    }

    @Test
    fun `unavailable requested model is reported rather than substituted`() {
        withServer(404, "{}") { coach, _, _ ->
            val error = assertFailsWith<CoachException> {
                runBlocking { coach.reply("test-key", "gemini-3.5-flash", dishes.first(), listOf(ChatMessage("Hi", true))) }
            }
            assertTrue(error.message!!.contains("gemini-3.5-flash"))
            assertTrue(error.message!!.contains("unavailable"))
        }
    }

    @Test
    fun `quota and blocked prompts have actionable errors`() {
        listOf(
            Triple(429, "{}", "quota"),
            Triple(200, """{"promptFeedback":{"blockReason":"SAFETY"}}""", "blocked"),
            Triple(200, """{"candidates":[{"finishReason":"SAFETY"}]}""", "rephrasing"),
        ).forEach { (status, body, expected) ->
            withServer(status, body) { coach, _, _ ->
                val error = assertFailsWith<CoachException> {
                    runBlocking { coach.reply("test-key", "gemini-3.5-flash", dishes.first(), listOf(ChatMessage("Hi", true))) }
                }
                assertTrue(error.message!!.contains(expected))
            }
        }
    }

    @Test
    fun `malformed or empty success is not treated as a reply`() {
        listOf("not json", "{}", """{"candidates":[{"content":{"parts":[{"text":"  "}]}}]}""").forEach { body ->
            withServer(200, body) { coach, _, _ ->
                assertFailsWith<CoachException> {
                    runBlocking { coach.reply("test-key", "gemini-3.5-flash", dishes.first(), listOf(ChatMessage("Hi", true))) }
                }
            }
        }
    }

    @Test
    fun `invalid credentials and model ids fail before network access`() {
        val coach = GeminiCoach(URI.create("http://127.0.0.1:1/"))
        listOf("" to "gemini-3.5-flash", "bad\nkey" to "gemini-3.5-flash", "test-key" to "../model").forEach { (key, model) ->
            assertFailsWith<CoachException> {
                runBlocking { coach.reply(key, model, dishes.first(), listOf(ChatMessage("Hi", true))) }
            }

            @Test
            fun `API key validation accepts header-safe punctuation and trims pasted whitespace`() {
                assertNull(apiKeyValidationError("  test.key/with+punctuation= \n"))
                assertTrue(apiKeyValidationError("bad key")!!.contains("spaces"))
                assertTrue(apiKeyValidationError("bad\nkey")!!.contains("spaces"))
                assertTrue(apiKeyValidationError(" \n")!!.contains("Enter"))
                assertTrue(modelValidationError("")!!.contains("model ID"))
            }

            @Test
            fun `punctuated keys are sent unchanged instead of being rejected locally`() {
                withServer(200, """{"candidates":[{"content":{"parts":[{"text":"Servus!"}]},"finishReason":"STOP"}]}""") { coach, _, key ->
                    runBlocking {
                        coach.reply("  test.key/with+punctuation=  ", "gemini-3.5-flash", dishes.first(), listOf(ChatMessage("Hi", true)))
                    }
                    assertEquals("test.key/with+punctuation=", key())
                }

                @Test
                fun `canceling a conversation cancels a pending response body read`() = runBlocking {
                    val received = CountDownLatch(1)
                    val release = CountDownLatch(1)
                    val server = HttpServer.create(InetSocketAddress("127.0.0.1", 0), 0)
                    server.createContext("/") { exchange ->
                        exchange.sendResponseHeaders(200, 100)
                        exchange.responseBody.write("{".toByteArray())
                        exchange.responseBody.flush()
                        received.countDown()
                        release.await(3, TimeUnit.SECONDS)
                        exchange.close()
                    }
                    server.start()
                    try {
                        val coach = GeminiCoach(URI.create("http://127.0.0.1:${server.address.port}/v1beta/"))
                        val request = launch {
                            coach.reply("test-key", "gemini-3.5-flash", dishes.first(), listOf(ChatMessage("Hi", true)))
                        }
                        assertTrue(withContext(Dispatchers.IO) { received.await(3, TimeUnit.SECONDS) })
                        withTimeout(1500) { request.cancelAndJoin() }
                        assertTrue(request.isCancelled)
                    } finally {
                        release.countDown()
                        server.stop(0)
                    }
                }
            }
        }
    }
}
