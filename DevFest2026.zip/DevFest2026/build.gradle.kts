plugins {
    kotlin("jvm") version "2.4.21"
    kotlin("plugin.compose") version "2.4.21"
    kotlin("plugin.serialization") version "2.4.21"
    id("org.jetbrains.compose") version "1.12.2"
    id("com.android.application") version "9.5.1" apply false
}

group = "at.wien.wordofmouth"
version = "1.0.0"

dependencies {
    implementation(compose.desktop.currentOs)
    implementation(compose.material3)
    implementation("org.jetbrains.kotlinx:kotlinx-coroutines-swing:1.10.2")
    implementation("org.jetbrains.kotlinx:kotlinx-serialization-json:1.9.0")
    implementation("com.squareup.okhttp3:okhttp:5.5.1")
    testImplementation(kotlin("test"))
}

kotlin {
    jvmToolchain(25)
    sourceSets.main {
        kotlin.srcDir("src/shared/kotlin")
    }
}

tasks.test {
    useJUnitPlatform()
}

tasks.withType<JavaExec>().configureEach {
    jvmArgs("--enable-native-access=ALL-UNNAMED")
}

compose.desktop {
    application {
        mainClass = "at.wien.wordofmouth.MainKt"
        nativeDistributions {
            packageName = "Word of Mouth"
            packageVersion = "1.0.0"
            modules("java.net.http")
        }
    }
}